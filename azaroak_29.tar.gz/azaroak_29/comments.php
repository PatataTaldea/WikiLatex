<?php
		$bisitak = simplexml_load_file('bisitak.xml');
		$berria = $bisitak->addChild('bisita');
		$berria->addChild('izena',$_POST['name']);
		if($_POST['email']!= ""){
			$berria->addChild('eposta',$_POST['email']);
		  }
		$berria->addChild('iruzkina',$_POST['iruz']);	
		$azkena = $bisitak['azkenid'];
		$zenbakia = substr($azkena,1) + 1;
		$berria->addAttribute('id',"b".$zenbakia);		
		$bisitak['azkenid'] = "b".$zenbakia;
		$bisitak->asXML('bisitak.xml');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head>
		<title></title>
		<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
		<!-- Ez ahaztu zure javascript fitxategiaren izena script etiketaren src atributuan zehazten. -->
		<script type="text/javascript" src=""></script>
	</head>
	<body>
	<style>
	body {text-align: center; color: #000000; background-color: #B4E3FA}
	h1 {font: 500% Arial; font-weight: bold;}
	h2, h3 {font: 200% Verdana}
	</style>
	<center>
		<br><br><br>
		<p><a href=oinarria.html>>>>Itzuli formulariora</a></p>
		<br><br><br>
		<h1>IRUZKINAK</h1><br>
		<table align="center" border="30">
		<tr align="center">
		<th>Bisitaria</th><th>Emaila</th><th>Iruzkina</th></tr>
		<?php
			$bisitak = simplexml_load_file('bisitak.xml');
			foreach($bisitak->bisita as $bisita){
				$berria = substr ($bisita->iruzkina,0,15);
				echo('<tr><td>'.$bisita->izena.'</td><td>'.$bisita->eposta.'</td><td>'.$berria.'<a href=#>IRUZKIN OSOA</a></td></tr>');
		   }
		?>
		</table><br>
		<p><img src=book.png width="300" height="250"/></p><br>
	</center>
	</body>
</html>
