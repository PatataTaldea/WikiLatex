<?php
			$bisitak = simplexml_load_file('bisitak.xml');
			foreach($bisitak->bisita as $bisita){
				echo('Izena: ' .$bisita->izena . '<br/>');
				echo('Emaila: ' .$bisita->eposta . '<br/>');
				echo('Iruzkina: ' .$bisita->iruzkina . '<br/>');
			}
			
		?>